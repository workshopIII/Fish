from flask import Flask, request, jsonify


## create a Flask instance

app = Flask(__name__)

# user class has login and set password operations 
class user():

    # create a login api
    @app.route("/login", methods=["POST"])
    def login():
        name = request.form.get("name")
        password = request.form.get("password")

    # check if name / password empty
    # "" 0 [] () {} None ==> False
        if not all([name, password]):
        # if any empty return error result
            return jsonify(code=1001, message='Parameter incomplete!')
            
        # on your project should check with DB
        # here just for case study
        if name == "admin" and password == "123321":
            return jsonify(code=0, message="Success!")
        else:
            return jsonify(code=1001, message="Not correct username or password!")
    
    # create a set password api 
    # set a new password
    @app.route("/set", methods=["POST"])
    def changePsw():
        password = request.form.get("password")
        password2 = request.form.get("password2")
        # check if password / password2 empty
        # "" 0 [] () {} None ==> False
        if not all([password, password2]):
        # if any empty return error result
            return jsonify(code = 1001, message="Password incomplete!")
        # check if password = password2
        if password == password2:
            return jsonify(code = 0, message="Success!")
        else:
            return jsonify(code = 1001, message="Two passwords are different!")

if __name__ == '__main__':
 ## debug parameter set as True to make changes without restarting the program
 app.run(debug=True)
